from benchmarks.benchmark_1 import benchmark_algorithms


if __name__ == "__main__":
    benchmark_algorithms()