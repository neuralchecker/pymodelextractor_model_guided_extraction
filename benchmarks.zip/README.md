# Experiments for model guided extraction from LMs
Library Versions Used:
<br>pythautomata==0.??
<br>pymodelextractor==0.??
